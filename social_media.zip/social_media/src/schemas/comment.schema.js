const Mongoose = require('mongoose');
const commentSchema = new Mongoose.Schema({
   user_id : String,
   post_id :String,
   comment:String

})

const commentModel =  Mongoose.model('comments',commentSchema);
module.exports.commentModel = commentModel ;