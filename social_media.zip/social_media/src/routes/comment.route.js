const express = require('express')
const router = express.Router()

const { getCommentsByPost, 
        addComment, 
        deleteComment } = require("../controllers/comment.controller")



router.get('/comments/getCommentsByPost/:postId', getCommentsByPost)
router.post('/comment/new',addComment)
router.put('/comment/delete/:id',deleteComment)

module.exports = router