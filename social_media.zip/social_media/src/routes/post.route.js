const express = require('express')
const router = express.Router()

const { getAll, getAllByUser, add, update, deletePost } = require("../controllers/post.controller")



router.get('/posts/all',getAll)
router.get('/posts/getAllByUser/:userId', getAllByUser)
router.post('/post/new',add)
router.put('/post/update',update)
router.put('/post/delete/:id',deletePost)

module.exports = router

