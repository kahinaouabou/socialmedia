const express = require('express')
const router = express.Router()

const { login, 
        getUser, 
        addUser, 
        deleteUser } = require("../controllers/user.controller")



router.post('/users/login',login)
router.get('/user/get/:id', getUser)
router.post('/user/inscription',addUser)
router.delete('/user/delete/:id',deleteUser)
module.exports = router