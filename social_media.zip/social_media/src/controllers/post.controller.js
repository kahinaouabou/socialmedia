const { postModel } = require("../schemas/post.schema") ;
const {postValidation} = require("../validations/post.validation")
const getAll = async(request, response)=>{
    let result = await postModel.find()
    response.send(result)
}
const getAllByUser = async(request, response)=>{
    let userId = request.params.userId;
    let result = await postModel.find({user_id:userId})
    response.send(result)
}

const add = async(request, response)=>{
    const {error,value} =postValidation(request.body);
    if(error){
        return response.send(error.details[0].message);
    }
    let newPost = new postModel({
        user_id:value.user_id,
        content:value.content
    })
    let result = await newPost.save()
    response.send(result)
}
const update = async(request, response)=>{
    let value = request.body;
   
    let result = await postModel.findByIdAndUpdate(value.id,{
        $set: {
            user_id:value.user_id,
            content:value.content
        }
    })
    response.send(result)
}
const deletePost = async(request, response)=>{
    let id = request.params.id;
    await postModel.findByIdAndDelete(id);
    response.send('deleted');
}

module.exports.getAll = getAll
module.exports.getAllByUser = getAllByUser
module.exports.add = add
module.exports.update = update
module.exports.deletePost = deletePost
