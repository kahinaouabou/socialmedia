const { commentModel } = require("../schemas/comment.schema") ;
const {commentValidation} = require("../validations/comment.validation")
const getCommentsByPost = async(request, response)=>{
    let postId = request.params.postId;
    let result = await commentModel.find({post_id:postId})
    response.send(result)
}

const addComment = async (request, response)=>{
    const {error,value} =commentValidation(request.body);
    if(error){
        return response.send(error.details[0].message);
    }
    let newCommand = new commentModel({
        user_id:value.user_id,
        post_id:value.post_id,
        comment:value.comment
    })
    let result = await newCommand.save()
    response.send(result)
}
const deleteComment = async(request, response)=>{
    let id = request.params.id;
    await commentModel.findByIdAndDelete(id);
    response.send('deleted');
}

module.exports.getCommentsByPost = getCommentsByPost
module.exports.addComment = addComment
module.exports.deleteComment = deleteComment