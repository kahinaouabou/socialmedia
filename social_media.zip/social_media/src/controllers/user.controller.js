const { userModel } = require("../schemas/user.schema") ;
const {userValidation} = require("../validations/user.validation")
const login = async (request, response)=>{
    let value = request.body;
    let email = value.email;
    let password = value.password;
   let result = await userModel.find({email:email, password:password})
   if(result.length> 0){
        response.send(result[0])
   }else {
    response.send("user not found")
   }
   
}
const getUser = async(request, response)=>{
    let id = request.params.id;
    let result = await userModel.findById(id);
    response.send(result)
}
const addUser = async(request, response)=>{
    
    const {error,value} =userValidation(request.body);
    if(error){
        return response.send(error.details[0].message);
    }
    let newUser = new userModel({
        username:value.username,
        email:value.email,
        password:value.password,
        birthdate:value.birthdate,
        gender :value.gender
    })
    let result = await newUser.save()
    response.send(result)
}

const deleteUser = async (request, response)=>{
    let id = request.params.id;
    await userModel.findByIdAndDelete(id);
    response.send('deleted');
}

module.exports.login = login
module.exports.getUser = getUser
module.exports.addUser = addUser
module.exports.deleteUser = deleteUser