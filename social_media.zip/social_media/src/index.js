const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan')
const Mongoose = require('mongoose')
const cors = require('cors')
const app = express()
const port = 8080 || env.PORT 

// setup express instance
app.use(express.json())
app.use(helmet())
app.use(morgan('dev'))
app.use(cors)


const userRoutes = require('./routes/user.route');
const postRoutes = require('./routes/post.route');
const commentRoutes = require('./routes/comment.route');
app.use(userRoutes);
app.use(postRoutes);
app.use(commentRoutes);
app.listen(port,()=>{
    console.log(`server started  on port : ${port}`)
    Mongoose.connect("mongodb+srv://admin:16kahina16@cluster0.8uytyvf.mongodb.net/social_media_db")
    .then(()=>{
        console.log('database connected')
    })
    .catch((error)=>{
        console.log(error)
    })
})