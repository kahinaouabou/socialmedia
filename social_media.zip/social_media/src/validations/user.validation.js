const joi = require('joi')

const userInputValidation =(input) => {
    const schema =joi.object({
        username :joi.string().max(25).min(3).required(),
        email :joi.string().email().required(),
        password :joi.string().required(),
        birthdate:joi.string().required(),
        gender: joi.string().required()

    })
    return schema.validate(input)
}

module.exports.userValidation = userInputValidation;