const joi = require('joi')

const commentInputValidation =(input) => {
    const schema =joi.object({
        user_id: joi.string().required(),
        post_id :joi.string().required(),
        comment: joi.string().required()

    })
    return schema.validate(input)
}

module.exports.commentValidation = commentInputValidation;