const joi = require('joi')

const postInputValidation =(input) => {
    const schema =joi.object({
        user_id: joi.string().required(),
        content: joi.string().required()

    })
    return schema.validate(input)
}

module.exports.postValidation = postInputValidation;